-- _05.lua - 함수

print("==== 연습 5-1: 다중 반환 ====")

local function getPlayerInfo()
    local x = 100
    local y = 200
    local angle = 90

    return x, y, angle
end

local playerX, playerY, playerAngle = getPlayerInfo()
print(playerX, playerY, playerAngle)


print("\n==== 연습 5-2: 고차 함수 ====")

local function map(numbers, callback)
    local result = {}

    for i = 1, #numbers do
        result[i] = callback(numbers[i])
    end

    return result
end

local numbers = {1, 2, 3, 4, 5}
local doubled = map(numbers, function(value)
    return value * 2
end)

print(table.concat(doubled, ", "))


print("\n==== 연습 5-3: 클로저 활용 ====")

local function makeHealthBar(maxHp)
    local hp = maxHp

    local function clamp(value, minValue, maxValue)
        if value < minValue then
            return minValue
        end

        if value > maxValue then
            return maxValue
        end

        return value
    end

    return {
        damage = function(amount)
            hp = clamp(hp - amount, 0, maxHp)
        end,

        heal = function(amount)
            hp = clamp(hp + amount, 0, maxHp)
        end,

        getPercent = function()
            return hp / maxHp * 100
        end,
    }
end

local healthBar = makeHealthBar(100)
healthBar.damage(30)
print(healthBar.getPercent()) -- 70
healthBar.heal(50)
print(healthBar.getPercent()) -- 100
healthBar.damage(200)
print(healthBar.getPercent()) -- 0


print("\n==== 연습 5-4: 콜론 문법 ====")

local enemy = {hp = 100, name = "Goblin"}

function enemy:takeDamage(amount)
    self.hp = self.hp - amount

    if self.hp <= 0 then
        print(self.name .. " is dead!")
    end
end

-- enemy.takeDamage(30)은 self 자리에 30이 들어가서 에러가 남
-- 콜론으로 호출하면 self에 enemy 테이블이 자동으로 전달됨
enemy:takeDamage(30)
print(enemy.name, enemy.hp)
