-- _04.lua - 문자열

print("==== 연습 4-1: string.format 활용 ====")

local wave = 3
local x, y = 12.5, -8.3
local hp = 100
local message = string.format("[Wave %02d] Enemy spawned at (%.2f, %.2f) - HP: %d", wave, x, y, hp)
print(message)


print("\n==== 연습 4-2: 패턴 매칭 ====")

local text = "Background: #FF0000, Text: #00FF00, Border: #0000FF"

for color in string.gmatch(text, "#%x%x%x%x%x%x") do
    print(color)
end


print("\n==== 연습 4-3: 효율적 문자열 연결 ====")

local parts = {}

for i = 1, 100 do
    parts[i] = tostring(i)
end

local result = table.concat(parts, ", ")
print(result)


print("\n==== 연습 4-4: 파싱 ====")

local input = "Player[Lv.15] HP:80/100"
local name, level, currentHp, maxHp = string.match(input, "([^%[]+)%[Lv%.(%d+)%] HP:(%d+)/(%d+)")

print("name:", name)
print("level:", tonumber(level))
print("currentHp:", tonumber(currentHp))
print("maxHp:", tonumber(maxHp))
