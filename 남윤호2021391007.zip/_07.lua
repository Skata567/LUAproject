-- _07.lua - 테이블 심화

print("==== 연습 7-1: 깊은 복사 + 순환 참조 ====")

local function deepCopy(value, visited)
    if type(value) ~= "table" then
        return value
    end

    visited = visited or {}

    if visited[value] then
        return visited[value]
    end

    local copy = {}
    visited[value] = copy

    for key, item in pairs(value) do
        copy[deepCopy(key, visited)] = deepCopy(item, visited)
    end

    return copy
end

local original = {value = 1}
original.self = original

local copied = deepCopy(original)
print(copied.value)
print(copied.self == copied)
print(copied ~= original)


print("\n==== 연습 7-2: 오브젝트 풀 ====")

local function createParticlePool(size)
    local pool = {
        inactive = {},
        active = {},
    }

    local function createParticle()
        return {
            x = 0,
            y = 0,
            vx = 0,
            vy = 0,
            life = 0,
            maxLife = 0,
        }
    end

    for i = 1, size do
        pool.inactive[i] = createParticle()
    end

    function pool:get()
        local particle = table.remove(self.inactive)

        if not particle then
            particle = createParticle()
        end

        self.active[#self.active + 1] = particle
        return particle
    end

    function pool:release(particle)
        for i = #self.active, 1, -1 do
            if self.active[i] == particle then
                table.remove(self.active, i)
                break
            end
        end

        particle.x = 0
        particle.y = 0
        particle.vx = 0
        particle.vy = 0
        particle.life = 0
        particle.maxLife = 0

        self.inactive[#self.inactive + 1] = particle
    end

    function pool:updateAll(dt)
        for i = #self.active, 1, -1 do
            local particle = self.active[i]
            particle.x = particle.x + particle.vx * dt
            particle.y = particle.y + particle.vy * dt
            particle.life = particle.life - dt

            if particle.life <= 0 then
                self:release(particle)
            end
        end
    end

    return pool
end

local particlePool = createParticlePool(2)
local particle = particlePool:get()
particle.x = 10
particle.y = 20
particle.vx = 5
particle.vy = -2
particle.life = 1
particle.maxLife = 1

particlePool:updateAll(0.5)
print("active:", #particlePool.active, "inactive:", #particlePool.inactive)
particlePool:updateAll(0.6)
print("active:", #particlePool.active, "inactive:", #particlePool.inactive)


print("\n==== 연습 7-3: Set 연산 ====")

local function toSet(array)
    local set = {}

    for i = 1, #array do
        set[array[i]] = true
    end

    return set
end

local function union(left, right)
    local result = {}

    for key in pairs(left) do
        result[key] = true
    end

    for key in pairs(right) do
        result[key] = true
    end

    return result
end

local function intersection(left, right)
    local result = {}

    for key in pairs(left) do
        if right[key] then
            result[key] = true
        end
    end

    return result
end

local function difference(left, right)
    local result = {}

    for key in pairs(left) do
        if not right[key] then
            result[key] = true
        end
    end

    return result
end

local function printSet(label, set)
    local values = {}

    for key in pairs(set) do
        values[#values + 1] = key
    end

    table.sort(values)
    print(label .. ": " .. table.concat(values, ", "))
end

local setA = toSet({"fire", "ice", "wind"})
local setB = toSet({"ice", "earth", "wind"})

printSet("union", union(setA, setB))
printSet("intersection", intersection(setA, setB))
printSet("difference", difference(setA, setB))


print("\n==== 연습 7-4: 안전한 접근 ====")

local function safeSet(t, value, ...)
    local keys = {...}

    if #keys == 0 then
        return false
    end

    local current = t

    for i = 1, #keys - 1 do
        local key = keys[i]

        if type(current[key]) ~= "table" then
            current[key] = {}
        end

        current = current[key]
    end

    current[keys[#keys]] = value
    return true
end

local data = {}
safeSet(data, 100, "player", "stats", "hp")
print(data.player.stats.hp)
