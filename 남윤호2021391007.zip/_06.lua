-- _06.lua - 테이블 기초

print("==== 연습 6-1: 인벤토리 시스템 ====")

local function addItem(inventory, item)
    inventory[#inventory + 1] = item
end

local function removeItem(inventory, index)
    if index < 1 or index > #inventory then
        return nil
    end

    return table.remove(inventory, index)
end

local function findItem(inventory, item)
    for i = 1, #inventory do
        if inventory[i] == item then
            return i
        end
    end

    return nil
end

local function printInventory(inventory)
    for i = 1, #inventory do
        print(i .. ". " .. inventory[i])
    end
end

local inventory = {}
addItem(inventory, "Sword")
addItem(inventory, "Shield")
addItem(inventory, "Potion")
printInventory(inventory)

print("Shield index:", findItem(inventory, "Shield"))
print("Removed:", removeItem(inventory, 2))
printInventory(inventory)


print("\n==== 연습 6-2: 점수 테이블 정렬 ====")

local leaderboard = {
    {name = "Alice", score = 1500},
    {name = "Bob", score = 2300},
    {name = "Charlie", score = 800},
}

table.sort(leaderboard, function(left, right)
    return left.score > right.score
end)

for i = 1, #leaderboard do
    local entry = leaderboard[i]
    print(string.format("%d. %s(%d)", i, entry.name, entry.score))
end


print("\n==== 연습 6-3: # 함정 이해 ====")

local a = {1, 2, 3}
local b = {1, nil, 3}
local c = {x = 1, y = 2, z = 3}
print(#a, #b, #c)

-- 설명:
-- #a는 연속 배열이므로 3이다.
-- #b는 중간에 nil 구멍이 있으므로 Lua 버전이나 구현에 따라 결과가 달라질 수 있다.
-- #c는 1, 2, 3 같은 배열 인덱스가 아니라 문자열 키만 있으므로 0이다.


print("\n==== 연습 6-4: Swap-Remove 구현 ====")

local function swapRemove(t, index)
    local lastIndex = #t

    if index < 1 or index > lastIndex then
        return nil
    end

    local removed = t[index]
    t[index] = t[lastIndex]
    t[lastIndex] = nil

    return removed
end

local values = {}

for i = 1, 100 do
    values[i] = i
end

print("Removed:", swapRemove(values, 50))
print("Length:", #values)
print("Index 50:", values[50])

-- table.remove(t, 50)은 51번부터 마지막 요소까지 한 칸씩 앞으로 당긴다.
-- swapRemove(t, 50)은 마지막 요소를 50번 자리로 옮기고 마지막 칸만 지운다.
-- swapRemove는 빠르지만 배열의 순서를 유지하지 않는다.
