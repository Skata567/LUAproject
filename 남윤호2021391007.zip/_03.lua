-- _03.lua - 제어문 & 연산자

print("==== 연습 3-1: switch 대체 ====")

local function getEnemySpeed(enemyType)
    local speedByEnemyType = {
        slime = 50,
        bat = 150,
        boss = 30,
    }

    return speedByEnemyType[enemyType] or 100
end

print(getEnemySpeed("slime")) -- 50
print(getEnemySpeed("bat"))   -- 150
print(getEnemySpeed("boss"))  -- 30
print(getEnemySpeed("ghost")) -- 100


print("\n==== 연습 3-2: continue 대체 ====")

-- continue가 없어도 조건을 만족할 때만 실행하면 같은 효과를 낼 수 있다.
for i = 1, 20 do
    if i % 3 == 0 then
        print(i)
    end
end


print("\n==== 연습 3-3: and/or 함정 ====")

local a = true and false or "fallback"
local b = true and 0 or "fallback"
local c = nil and "yes" or "no"

print(a, b, c) -- fallback 0 no

-- 설명:
-- true and false는 false가 되고, false or "fallback"은 "fallback"이 된다.
-- true and 0은 0이 되고, Lua에서 0은 참이므로 0 or "fallback"은 0이 된다.
-- nil and "yes"는 nil이 되고, nil or "no"는 "no"가 된다.


print("\n==== 연습 3-4: 숫자 for 차이 ====")

-- C의 for (int i = 0; i < 10; i++)는 0부터 9까지 반복한다.
-- Lua의 숫자 for는 끝값을 포함하므로 끝값을 9로 잡아야 한다.
for i = 0, 9 do
    print(i)
end
