-- _02.lua - 타입 & 변수

print("==== 연습 2-1: 타입 확인 ====")
print(type(42))       -- number
print(type(42.0))     -- number
print(type("42"))     -- string
print(type(nil))      -- nil
print(type(true))     -- boolean
print(type(print))    -- function
print(type({}))       -- table
print(type(type))     -- function


print("\n==== 연습 2-2: 전역 오염 찾기 ====")

-- 함수 안에서만 쓰는 값은 local로 선언해야 전역 변수를 오염시키지 않는다.
local function createBullet(x, y)
    local speed = 500
    local dx = 0
    local dy = -1
    local bullet = {
        x = x,
        y = y,
        speed = speed,
        dx = dx,
        dy = dy,
    }

    return bullet
end

local bullet = createBullet(100, 200)
print(bullet.x, bullet.y, bullet.speed, bullet.dx, bullet.dy)


print("\n==== 연습 2-3: 다중 할당 ====")

local a, b, c = 10, 20, 30
a, c = c, a
print(a, b, c) 


print("\n==== 연습 2-4: 진위 판별 ====")

-- Lua에서 거짓은 false와 nil뿐이기 때문에
-- 0, 0.0, 빈 문자열, "false" 문자열은 모두 참으로 처리된다.
if 0 then print("A") end
if "" then print("B") end
if nil then print("C") end
if false then print("D") end
if 0.0 then print("E") end
if "false" then print("F") end
